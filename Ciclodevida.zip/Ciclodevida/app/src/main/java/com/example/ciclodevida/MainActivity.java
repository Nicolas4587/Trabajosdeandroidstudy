package com.example.ciclodevida;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toast.makeText(this, "In onCreate", Toast.LENGTH_SHORT).show();
        Log.i("mi_mensaje", "In create De nicolas");




    }

    @Override
    protected void onStart() {
        super.onStart();
        Toast.makeText(this, "In onStart", Toast.LENGTH_SHORT).show();
        Log.i("mi_mensaje", "In onStrart de nicolas");

    }


        @Override
    protected void onResume() {
        super.onResume();
        Toast.makeText(this, "In onResumen", Toast.LENGTH_SHORT).show();
        Log.i("mi_mensaje", "In onResumen de nicolas");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Toast.makeText(this, "In onPause", Toast.LENGTH_SHORT).show();
        Log.i("mi_mensaje", "In onPause de nicolas");

    }

    @Override
    protected void onStop() {
        super.onStop();
        Toast.makeText(this, "In onStop", Toast.LENGTH_SHORT).show();
        Log.i("mi_mensaje", "In onStop de nicolas");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Toast.makeText(this, "In onDestroy", Toast.LENGTH_SHORT).show();
        Log.i("mi_mensaje", "In onDestroy de nicolas");
    }
}
