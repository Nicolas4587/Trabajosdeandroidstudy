package com.example.proyectodespuesdeulibro6deseptiembre;

import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class AccounAdapter extends RecyclerView.Adapter<AccountCustomAdapter.ViewHolder>() {

    private ArrayLisr<Account> dataSet;

    public AccountAdapter(ArrayList<Account>dataSet){
        this.dataSet = dataSet;

    }
    @NonNull
    @Override
    public AccountAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType
        View myView = LayoutInflater.from(parent.getContext())
               .interface
        )

    public class ViewHolder extends RecyclerView.ViewHolder{

        private TextView tvName, tvCurrentValue,tvType;

        private ImageView ivPrincipal;

        public ViewHolder(@NonNull View itemView){
            super(itemView);

            tvName = itemView.findViewById(R.id.tv_item_name_account);
            tvCurrentValue = itemView.findViewById(R.id.tv_balance_account);
            tvType = itemView.findViewById(R.id.tv_item_balance_account);


        }

        public void loadItem(Account myAccount){
            tvName.setText(myAccount.getName());
            tvCurrentValue.setText(String.valueOf(myAccount.getCurrentValue()));
            tvType.setText(myAccount.getTypeAccount());


        }
    }


}
