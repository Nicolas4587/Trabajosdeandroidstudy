package com.example.proyectodespuesdeulibro6deseptiembre;

import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class NewaccountActivy { extends  AppCompatActivity{

    private ImageView ivback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_account);

        ivback=findViewById(R.id.iv_back);


    }

}
}
