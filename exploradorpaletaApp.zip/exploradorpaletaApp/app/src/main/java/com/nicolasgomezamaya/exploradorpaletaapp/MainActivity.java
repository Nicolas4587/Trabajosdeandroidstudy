package com.nicolasgomezamaya.exploradorpaletaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextClock;

public class MainActivity extends AppCompatActivity {


    private RadioGroup radioGroup;

    private TextClock textClock;

    private CheckBox cbTransparente, cbColor, cbTamaño;
    private ImageView ivLogo;
    private Switch sOcular;
    private boolean ischecked;


    @SuppressLint({"MissingInflatedId", "WrongViewCast"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.vista_principal);

        radioGroup = findViewById(R.id.radio_group);
        textClock = findViewById(R.id.tc_hora);

        sOcular = findViewById(R.id.s_ocultar);
        ivLogo = findViewById(R.id.iv_logo);
        cbTransparente = findViewById(R.id.cb_transparente);
        cbColor = findViewById(R.id.cb_color);
        cbTamaño = findViewById(R.id.cb_tamano);




        radioGroup. setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup Group, int checkedId) {

                RadioButton rb = findViewById(checkedId);

                if (rb.getId() == R.id.rb_beiging) {
                    textClock.setTimeZone("Etc/GMT-8");
                } else if (rb.getId() == R.id.rb_london) {
                    textClock.setTimeZone("Europe/London");
                } else if (rb.getId() == R.id.rb_bogota) {
                    textClock.setTimeZone("America/Bogota");
                } else if (rb.getId() == R.id.rb_new_york) {
                    textClock.setTimeZone("America/New_York");


                }


            }
        });

        sOcular.setChecked(true);
        sOcular.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (ischecked){
                    ivLogo.setVisibility(View.VISIBLE);
                }else {
                    ivLogo.setVisibility(View.INVISIBLE);
                }
            }
        });

        cbTransparente.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (cbTransparente.isChecked()){
                    ivLogo.setAlpha(0.1f);

                }else{
                    ivLogo.setAlpha(1f);
                }
            }
        });

        cbColor.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (cbColor.isChecked()){
                    ivLogo.setColorFilter(Color.argb(150,0,0,0));
                }
                else {
                    ivLogo.setColorFilter(Color.argb(0,0,0,0));
                }
            }
        });

        cbTamaño.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (cbTamaño.isChecked()){
                    ivLogo.setScaleX(2);
                    ivLogo.setScaleY(2);
                }
                else {
                    ivLogo.setScaleX(1);
                    ivLogo.setScaleY(1);
                }
            }
        });




    }
}